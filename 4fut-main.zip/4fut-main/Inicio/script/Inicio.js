let aviso = document.getElementById("box-msg");


function FecharAviso() {
  
  aviso.classList.add("AvisoN")
}